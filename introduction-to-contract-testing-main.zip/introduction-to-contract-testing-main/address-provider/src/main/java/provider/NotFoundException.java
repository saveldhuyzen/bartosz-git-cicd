package provider;

public class NotFoundException extends RuntimeException {

}
