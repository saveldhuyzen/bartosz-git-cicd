package provider;

public class BadRequestException extends RuntimeException {

}
