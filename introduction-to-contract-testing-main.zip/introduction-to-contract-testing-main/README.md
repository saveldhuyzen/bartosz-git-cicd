# Introduction to contract testing

This is the codebase associated with the [Introduction to contract testing workshop](https://www.ontestautomation.com/training/contract-testing/) I've been running successfully for a number of years now.

### Prerequisites
* Java 17
* Maven
* A free [PactFlow](https://www.pactflow.io) account

### Interested in this workshop?
Send me an email at bas@ontestautomation.com and I'm happy to discuss options.