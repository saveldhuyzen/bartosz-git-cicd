package order;

public class Address {

    public static final String VALID_EXISTING_ADDRESS_ID = "8aed8fad-d554-4af8-abf5-a65830b49a5f";
    public static final String VALID_NON_EXISTING_ADDRESS_ID = "00000000-0000-0000-0000-000000000000";
    public static final String INVALID_ADDRESS_ID = "this_is_not_a_valid_address_id";
}
